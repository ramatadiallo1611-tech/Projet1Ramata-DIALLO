# Projet 1 — Analyse des journaux d'un pare-feu

**Auteur : SANE Khadim** (L3 — Réseaux / Sécurité / IoT)

## Objectif
Analyser une semaine de connexions enregistrées par un pare-feu (`data/logs_reseau.csv`),
nettoyer les données, repérer les comportements suspects et proposer des recommandations.

## Lancer le projet
```bash
pip install -r requirements.txt
python analyse.py
```

Le script :
- nettoie les données (doublons, `protocol` en majuscules, `bytes_sent` manquants → médiane) ;
- écrit les 5 résultats dans `resultats.json` ;
- enregistre 5 figures dans `figures/` ;
- affiche dans la console des indicateurs complémentaires utilisés dans `rapport.md`.

## Contenu du dépôt
| Fichier | Rôle |
|---|---|
| `analyse.py` | script d'analyse |
| `resultats.json` | résultats générés par `analyse.py` |
| `rapport.md` | rapport d'analyse et recommandations |
| `figures/*.png` | graphiques générés |
| `data/logs_reseau.csv` | journaux du pare-feu |
| `requirements.txt` | dépendances (pandas, matplotlib) |
